# Basketball Score App

Aplicación Android para gestionar el marcador de un partido de baloncesto. Proyecto del primer trimestre usando Views, Layouts, Intents y Data Binding.

## Descripción

Aplicación móvil para llevar el marcador de un partido de baloncesto en tiempo real. Tiene dos pantallas:

1. **MainActivity**: Pantalla principal con botones para sumar y restar puntos
2. **ScoreActivity**: Pantalla que muestra el resultado final y quién ganó

## Funcionalidades

### MainActivity
- Marcadores para equipos Local y Visitante
- Botones +1 y +2 para sumar puntos (verde)
- Botón -1 para restar puntos (rojo), no permite negativos
- Botón de reset para poner todo en 0
- Botón para ver los resultados finales
- Funciona en vertical y horizontal

### ScoreActivity
- Muestra el marcador final "X - Y"
- Indica quién ganó o si fue empate
- Botón para volver al inicio
- Diseño adaptado para ambas orientaciones

## Tecnologías

- Kotlin 2.2.0
- Data Binding (sin findViewById)
- ConstraintLayout para los layouts
- CardView para las tarjetas
- Explicit Intents para navegar entre pantallas
- Strings en strings.xml
- Vector Drawables para los iconos

### Estructura del Proyecto
```
app/
├── src/main/
│   ├── java/com/example/basketball/
│   │   ├── MainActivity.kt          # Activity principal con lógica de marcador
│   │   ├── ScoreActivity.kt         # Activity de resultados finales
│   │   └── Constants.kt             # Constantes para claves de Intent
│   ├── res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml    # Layout de MainActivity (vertical)
│   │   │   └── activity_score.xml   # Layout de ScoreActivity (vertical)
│   │   ├── layout-land/
│   │   │   ├── activity_main.xml    # Layout de MainActivity (horizontal)
│   │   │   └── activity_score.xml   # Layout de ScoreActivity (horizontal)
│   │   ├── drawable/
│   │   │   ├── ic_basketball.xml    # Icono de baloncesto
│   │   │   ├── ic_reset.xml         # Icono de reset
│   │   │   ├── ic_arrow_forward.xml # Icono de flecha
│   │   │   ├── button_score_positive.xml    # Botón verde (+1, +2)
│   │   │   ├── button_score_negative.xml    # Botón rojo (-1)
│   │   │   ├── button_background_gradient.xml # Botón con gradiente
│   │   │   ├── score_background_premium.xml   # Fondo del marcador
│   │   │   ├── background_gradient.xml        # Fondo de pantalla
│   │   │   └── message_background.xml         # Fondo del mensaje
│   │   └── values/
│   │       ├── strings.xml          # Recursos de texto
│   │       ├── colors.xml           # Paleta de colores
│   │       └── themes.xml           # Temas de la aplicación
│   └── AndroidManifest.xml
└── build.gradle.kts                 # Configuración con Data Binding habilitado
```

## Implementación

### Data Binding

Configurado en build.gradle.kts:
```kotlin
buildFeatures {
    dataBinding = true
}
```

Uso en el código:
```kotlin
binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
binding.textViewLocalScore.text = localScore.toString()
```

### Paso de Datos

Se pasan los marcadores usando Intent extras con constantes:

```kotlin
// Enviar
val intent = Intent(this, ScoreActivity::class.java)
intent.putExtra(Constants.EXTRA_LOCAL_SCORE, localScore)
intent.putExtra(Constants.EXTRA_VISITOR_SCORE, visitorScore)
startActivity(intent)

// Recibir
val localScore = intent.getIntExtra(Constants.EXTRA_LOCAL_SCORE, 0)
val visitorScore = intent.getIntExtra(Constants.EXTRA_VISITOR_SCORE, 0)
```

### Rotación de Pantalla

Los marcadores se guardan al rotar:
```kotlin
override fun onSaveInstanceState(outState: Bundle) {
    super.onSaveInstanceState(outState)
    outState.putInt("localScore", localScore)
    outState.putInt("visitorScore", visitorScore)
}
```

### Validación

No permite marcadores negativos:
```kotlin
if (localScore > 0) {
    localScore--
}
```

## Diseño

- CardViews con bordes redondeados y sombras
- Gradientes en botones y marcador final
- Colores: Azul (Local), Rojo (Visitante), Verde (botones +), Naranja (principal)
- Marcadores grandes y visibles
- Layouts separados para vertical y horizontal

## Instalación

1. Abrir el proyecto en Android Studio
2. Sincronizar Gradle
3. Ejecutar en dispositivo o emulador

## Uso

- Botones +1 y +2 para sumar puntos
- Botón -1 para restar (no permite negativos)
- Botón reset para poner todo en 0
- Botón flecha para ver resultados
- Botón "Volver al Inicio" en la pantalla de resultados

## ⚠️ Errores Encontrados y Soluciones

Durante el desarrollo de la aplicación se encontraron varios errores que fueron solucionados. Esta sección documenta los problemas más comunes y sus soluciones.

### 1. Error: Atributo `android:strokeLinecap` no encontrado en Vector Drawable

**Error:**
```
Android resource linking failed
com.example.basketball.app-main-39:/drawable/ic_basketball.xml:16: 
error: attribute android:strokeLinecap not found.
```

**Causa:**
El atributo `android:strokeLinecap` no es válido en vector drawables de Android. Este atributo se intentó usar en el drawable del baloncesto para crear líneas con extremos redondeados.

**Solución:**
Se eliminó el atributo `android:strokeLinecap` y se separaron las líneas del baloncesto en paths individuales. Se agregó `fillColor` transparente a los paths que usan stroke:

```xml
<!-- ❌ Incorrecto -->
<path
    android:strokeColor="#000000"
    android:strokeWidth="1.5"
    android:strokeLinecap="round"  <!-- Este atributo no existe -->
    android:pathData="M12,2L12,22"/>

    <!-- ✅ Correcto -->
<path
android:fillColor="#00000000"
android:strokeColor="#000000"
android:strokeWidth="1.5"
android:pathData="M12,2L12,22"/>
```

**Archivo afectado:** `app/src/main/res/drawable/ic_basketball.xml`

---

### 2. Error: Incompatibilidad de Versiones de Kotlin

**Error:**
```
Module was compiled with an incompatible version of Kotlin. 
The binary version of its metadata is 2.2.0, expected version is 2.0.0.
```

**Causa:**
Las dependencias del proyecto estaban compiladas con Kotlin 2.2.0, pero el proyecto estaba configurado para usar Kotlin 2.0.21, causando una incompatibilidad de metadatos.

**Solución:**
Se actualizó la versión de Kotlin en `gradle/libs.versions.toml` de `2.0.21` a `2.2.0` para que coincida con las dependencias:

```toml
[versions]
kotlin = "2.2.0"  # Actualizado desde 2.0.21
```

**Archivo afectado:** `gradle/libs.versions.toml`

**Nota:** Después de cambiar la versión, es recomendable ejecutar `./gradlew clean` para limpiar los archivos compilados antiguos.

---

### 3. Error: Archivos de Compose no utilizados causando errores de compilación

**Error:**
```
e: Unresolved reference 'compose'
e: Unresolved reference 'Color'
e: Unresolved reference 'MaterialTheme'
```

**Causa:**
El proyecto original tenía archivos de Jetpack Compose (`Color.kt`, `Theme.kt`, `Type.kt`) que no se necesitaban porque la aplicación usa Views tradicionales con Data Binding. Estos archivos intentaban importar librerías de Compose que no estaban disponibles.

**Solución:**
Se eliminaron los archivos de Compose que no se utilizaban:

- `app/src/main/java/com/example/basketball/ui/theme/Color.kt`
- `app/src/main/java/com/example/basketball/ui/theme/Theme.kt`
- `app/src/main/java/com/example/basketball/ui/theme/Type.kt`

También se eliminó la dependencia de Compose del `build.gradle.kts` y se deshabilitó el plugin de Compose.

---

### 4. Error: Crash al abrir ScoreActivity

**Error:**
La aplicación se cerraba inmediatamente al presionar el botón para ver los resultados.

**Causa:**
El layout de `activity_score.xml` tenía un CardView anidado dentro de otro CardView para el botón, y el CardView externo tenía un `cardBackgroundColor` con un drawable selector, lo cual causaba conflictos de renderizado.

**Solución:**
Se simplificó el layout eliminando el CardView anidado del botón y usando directamente el Button con el drawable de fondo:

```xml
<!-- ❌ Incorrecto -->
<androidx.cardview.widget.CardView
    app:cardBackgroundColor="@drawable/button_background_gradient">
    <Button
        android:background="@drawable/button_background_gradient" />
</androidx.cardview.widget.CardView>

    <!-- ✅ Correcto -->
<Button
android:background="@drawable/button_background_gradient"
android:elevation="14dp" />
```

**Archivo afectado:** `app/src/main/res/layout/activity_score.xml`

---

### 5. Error: Tema no disponible

**Error:**
La aplicación no iniciaba correctamente debido a un tema no disponible.

**Causa:**
El tema estaba configurado como `android:Theme.Material.Light.NoActionBar`, que puede no estar disponible en todas las versiones de Android o requiere dependencias adicionales.

**Solución:**
Se cambió el tema a `Theme.AppCompat.Light.NoActionBar` que es más compatible:

```xml
<!-- ❌ Incorrecto -->
<style name="Theme.Basketball" parent="android:Theme.Material.Light.NoActionBar" />

    <!-- ✅ Correcto -->
<style name="Theme.Basketball" parent="Theme.AppCompat.Light.NoActionBar">
<item name="colorPrimary">@color/button_primary</item>
<item name="colorPrimaryDark">@color/button_primary_dark</item>
<item name="colorAccent">@color/primary_blue</item>
</style>
```

**Archivo afectado:** `app/src/main/res/values/themes.xml`

---

### 6. Error: Marcadores se pierden al rotar la pantalla

**Problema:**
Al rotar el dispositivo, los marcadores volvían a 0, perdiendo los valores ingresados.

**Causa:**
No se estaba guardando el estado de las variables cuando Android recreaba la Activity debido al cambio de orientación.

**Solución:**
Se implementó `onSaveInstanceState()` para guardar los valores y se restauraron en `onCreate()`:

```kotlin
override fun onSaveInstanceState(outState: Bundle) {
    super.onSaveInstanceState(outState)
    outState.putInt("localScore", localScore)
    outState.putInt("visitorScore", visitorScore)
}

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // ...
    if (savedInstanceState != null) {
        localScore = savedInstanceState.getInt("localScore", 0)
        visitorScore = savedInstanceState.getInt("visitorScore", 0)
    }
}
```

**Archivos afectados:** `MainActivity.kt`, `ScoreActivity.kt`

---

## Posibles Errores

**"Cannot resolve symbol 'R'"**
- Limpiar y reconstruir el proyecto
- Sincronizar Gradle

**"Data binding class not generated"**
- Verificar que `dataBinding = true` esté en build.gradle.kts
- Asegurarse de que los layouts tengan `<layout>`

**Crash al abrir ScoreActivity**
- Verificar que el layout no tenga CardViews anidados problemáticos
- Revisar que los drawables estén correctos

**Marcadores se pierden al rotar**
- Verificar que `onSaveInstanceState` esté implementado
- Comprobar que se restauren en `onCreate`

---

## Dependencias

```kotlin
androidx.appcompat:appcompat:1.6.1
com.google.android.material:material:1.11.0
androidx.constraintlayout:constraintlayout:2.1.4
androidx.cardview:cardview:1.0.0
```

## Versiones

- Kotlin: 2.2.0
- Compile SDK: 36
- Min SDK: 24
