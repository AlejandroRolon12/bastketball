package com.example.basketball

object Constants {
    const val EXTRA_LOCAL_SCORE = "extra_local_score"
    const val EXTRA_VISITOR_SCORE = "extra_visitor_score"
}
